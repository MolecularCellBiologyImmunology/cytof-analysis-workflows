## ---- include = FALSE----------------------------------------------------
knitr::opts_chunk$set(comment = "#>", collapse = TRUE)

## ---- eval = FALSE-------------------------------------------------------
#  #' @include class-a.r
#  setClass("B", contains = "A")

