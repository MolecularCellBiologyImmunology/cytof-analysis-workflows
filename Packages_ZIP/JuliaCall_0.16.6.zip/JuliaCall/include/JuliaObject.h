#ifndef JuliaObject__JuliaObject__h
#define JuliaObject__JuliaObject__h

#include "JuliaObject/JuliaObject.hpp"
// possibly other
// header files
// to include

#endif // hinterface__hinterface__h
