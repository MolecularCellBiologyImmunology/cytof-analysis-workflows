shiny::runApp(system.file("shinyDemo", package = "rgl"),
              launch.browser = TRUE)
