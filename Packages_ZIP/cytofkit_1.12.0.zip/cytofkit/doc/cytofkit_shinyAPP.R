## ---- eval=FALSE-----------------------------------------------------------
#  require(cytofkit)
#  cytofkitShinyAPP()

