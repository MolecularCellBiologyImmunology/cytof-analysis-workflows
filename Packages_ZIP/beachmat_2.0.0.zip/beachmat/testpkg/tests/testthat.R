library(testthat)
library(beachtest)
test_check("beachtest")
