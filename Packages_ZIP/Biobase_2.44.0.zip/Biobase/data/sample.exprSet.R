if(interactive())
{
  message("Biobase 'sample.exprSet' dataset is defunct. Use 'sample.ExpressionSet' instead.")
}