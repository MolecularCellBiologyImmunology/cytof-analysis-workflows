## #include <Rcpp.h>

## // Generate engine called eng_org.

## #include <Rcpp.h>

## #include <Rcpp.h>

## #include <Rcpp.h>

## #include <Rcpp.h>

## #include <Rcpp.h>

## #ifdef _OPENMP

## #ifdef _OPENMP

## PKG_LIBS =  $(LAPACK_LIBS) $(BLAS_LIBS) $(FLIBS) $(SHLIB_OPENMP_CFLAGS)

## #include <Rcpp.h>

