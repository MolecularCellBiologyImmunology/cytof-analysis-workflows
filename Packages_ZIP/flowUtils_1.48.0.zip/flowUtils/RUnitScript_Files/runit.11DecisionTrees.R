  fcsFile<-system.file("extdata/List-modeDataFiles","int-gating_test_file_4D.fcs",package="gatingMLData")
  gateFile <- system.file("extdata/Gating-MLFiles","11DecisionTrees.xml",package="gatingMLData")
  csvFile<-paste(system.file("extdata/ExpectedResults/11DecisionTrees",package="gatingMLData"))
  flowEnv=new.env()
  read.gatingML(gateFile,flowEnv)
  fcs <- read.FCS(fcsFile,transformation=FALSE)
 

test.G1D_E<- function() {
  gateId<-"G1D-E"
      csvFile<-paste(csvFile,"/",gateId,".txt",sep="")
      expectedResult<-read.csv(csvFile,header=TRUE)
      flowUtils:::performGateTest(gateId,fcs,expectedResult,flowEnv)
}

test.G1D_G<- function() {
  gateId<-"G1D-G"
      csvFile<-paste(csvFile,"/",gateId,".txt",sep="")
      expectedResult<-read.csv(csvFile,header=TRUE)
      flowUtils:::performGateTest(gateId,fcs,expectedResult,flowEnv)
}

test.G1D_L<- function() {
  gateId<-"G1D-L"
      csvFile<-paste(csvFile,"/",gateId,".txt",sep="")
      expectedResult<-read.csv(csvFile,header=TRUE)
      flowUtils:::performGateTest(gateId,fcs,expectedResult,flowEnv)
}

test.G2D_GG<- function() {
  gateId<-"G2D-GG"
      csvFile<-paste(csvFile,"/",gateId,".txt",sep="")
      expectedResult<-read.csv(csvFile,header=TRUE)
      flowUtils:::performGateTest(gateId,fcs,expectedResult,flowEnv)
}

test.G2D_GL<- function() {
  gateId<-"G2D-GL"
      csvFile<-paste(csvFile,"/",gateId,".txt",sep="")
      expectedResult<-read.csv(csvFile,header=TRUE)
      flowUtils:::performGateTest(gateId,fcs,expectedResult,flowEnv)
}

test.G2D_LG<- function() {
  gateId<-"G2D-LG"
      csvFile<-paste(csvFile,"/",gateId,".txt",sep="")
      expectedResult<-read.csv(csvFile,header=TRUE)
      flowUtils:::performGateTest(gateId,fcs,expectedResult,flowEnv)
}

test.G2D_LL<- function() {
  gateId<-"G2D-LL"
      csvFile<-paste(csvFile,"/",gateId,".txt",sep="")
      expectedResult<-read.csv(csvFile,header=TRUE)
      flowUtils:::performGateTest(gateId,fcs,expectedResult,flowEnv)
}

test.G4D_GGGG<- function() {
  gateId<-"G4D-GGGG"
      csvFile<-paste(csvFile,"/",gateId,".txt",sep="")
      expectedResult<-read.csv(csvFile,header=TRUE)
      flowUtils:::performGateTest(gateId,fcs,expectedResult,flowEnv)
}

test.G4D_GGGL<- function() {
  gateId<-"G4D-GGGL"
      csvFile<-paste(csvFile,"/",gateId,".txt",sep="")
      expectedResult<-read.csv(csvFile,header=TRUE)
      flowUtils:::performGateTest(gateId,fcs,expectedResult,flowEnv)
}

test.G4D_GGLG<- function() {
  gateId<-"G4D-GGLG"
      csvFile<-paste(csvFile,"/",gateId,".txt",sep="")
      expectedResult<-read.csv(csvFile,header=TRUE)
      flowUtils:::performGateTest(gateId,fcs,expectedResult,flowEnv)
}

test.G4D_GGLL<- function() {
  gateId<-"G4D-GGLL"
      csvFile<-paste(csvFile,"/",gateId,".txt",sep="")
      expectedResult<-read.csv(csvFile,header=TRUE)
      flowUtils:::performGateTest(gateId,fcs,expectedResult,flowEnv)
}

test.G4D_GLGG<- function() {
  gateId<-"G4D-GLGG"
      csvFile<-paste(csvFile,"/",gateId,".txt",sep="")
      expectedResult<-read.csv(csvFile,header=TRUE)
      flowUtils:::performGateTest(gateId,fcs,expectedResult,flowEnv)
}

test.G4D_GLGL<- function() {
  gateId<-"G4D-GLGL"
      csvFile<-paste(csvFile,"/",gateId,".txt",sep="")
      expectedResult<-read.csv(csvFile,header=TRUE)
      flowUtils:::performGateTest(gateId,fcs,expectedResult,flowEnv)
}

test.G4D_GLLG<- function() {
  gateId<-"G4D-GLLG"
      csvFile<-paste(csvFile,"/",gateId,".txt",sep="")
      expectedResult<-read.csv(csvFile,header=TRUE)
      flowUtils:::performGateTest(gateId,fcs,expectedResult,flowEnv)
}

test.G4D_GLLL<- function() {
  gateId<-"G4D-GLLL"
      csvFile<-paste(csvFile,"/",gateId,".txt",sep="")
      expectedResult<-read.csv(csvFile,header=TRUE)
      flowUtils:::performGateTest(gateId,fcs,expectedResult,flowEnv)
}

test.G4D_LGGG<- function() {
  gateId<-"G4D-LGGG"
      csvFile<-paste(csvFile,"/",gateId,".txt",sep="")
      expectedResult<-read.csv(csvFile,header=TRUE)
      flowUtils:::performGateTest(gateId,fcs,expectedResult,flowEnv)
}

test.G4D_LGGL<- function() {
  gateId<-"G4D-LGGL"
      csvFile<-paste(csvFile,"/",gateId,".txt",sep="")
      expectedResult<-read.csv(csvFile,header=TRUE)
      flowUtils:::performGateTest(gateId,fcs,expectedResult,flowEnv)
}

test.G4D_LGLG<- function() {
  gateId<-"G4D-LGLG"
      csvFile<-paste(csvFile,"/",gateId,".txt",sep="")
      expectedResult<-read.csv(csvFile,header=TRUE)
      flowUtils:::performGateTest(gateId,fcs,expectedResult,flowEnv)
}

test.G4D_LGLL<- function() {
  gateId<-"G4D-LGLL"
      csvFile<-paste(csvFile,"/",gateId,".txt",sep="")
      expectedResult<-read.csv(csvFile,header=TRUE)
      flowUtils:::performGateTest(gateId,fcs,expectedResult,flowEnv)
}

test.G4D_LLGG<- function() {
  gateId<-"G4D-LLGG"
      csvFile<-paste(csvFile,"/",gateId,".txt",sep="")
      expectedResult<-read.csv(csvFile,header=TRUE)
      flowUtils:::performGateTest(gateId,fcs,expectedResult,flowEnv)
}

test.G4D_LLGL<- function() {
  gateId<-"G4D-LLGL"
      csvFile<-paste(csvFile,"/",gateId,".txt",sep="")
      expectedResult<-read.csv(csvFile,header=TRUE)
      flowUtils:::performGateTest(gateId,fcs,expectedResult,flowEnv)
}

test.G4D_LLLG<- function() {
  gateId<-"G4D-LLLG"
      csvFile<-paste(csvFile,"/",gateId,".txt",sep="")
      expectedResult<-read.csv(csvFile,header=TRUE)
      flowUtils:::performGateTest(gateId,fcs,expectedResult,flowEnv)
}

test.G4D_LLLL<- function() {
  gateId<-"G4D-LLLL"
      csvFile<-paste(csvFile,"/",gateId,".txt",sep="")
      expectedResult<-read.csv(csvFile,header=TRUE)
      flowUtils:::performGateTest(gateId,fcs,expectedResult,flowEnv)
}