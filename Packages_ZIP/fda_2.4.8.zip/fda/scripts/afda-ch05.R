###
###
### Ramsey & Silverman (2002) Applied Functional Data Analysis (Springer)
###
### ch. 5.  Modeling reaction-time distributions
###

# data not available 
