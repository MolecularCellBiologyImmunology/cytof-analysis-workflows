###
###
### Ramsey & Silverman (2006) Functional Data Analysis, 2nd ed. (Springer)
###
### ch. 7.  The registration and display of functional data
###
library(fda)

##
## Section 7.1.  Introduction
##
# pp. 128-129, Figure 7.1.  Amplitude vs. phase variation

