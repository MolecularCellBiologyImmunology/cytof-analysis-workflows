###
###
### Ramsey & Silverman (2002) Applied Functional Data Analysis (Springer)
###
### ch. 7.  Warping handwriting and weather records 
###
library(fda)

