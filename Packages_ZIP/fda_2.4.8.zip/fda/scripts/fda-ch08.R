###
###
### Ramsey & Silverman (2006) Functional Data Analysis, 2nd ed. (Springer)
###
### ch. 8
###
library(fda)
##
## Section 8.1.  
##
