  fcsFile<-system.file("extdata/List-modeDataFiles","int-10_events_6_parameters.fcs",package="gatingMLData")
  gateFile <- system.file("extdata/Gating-MLFiles","29TrSplitScale.xml",package="gatingMLData")
  csvFile<-paste(system.file("extdata/ExpectedResults/29TrSplitScale",package="gatingMLData"))
  flowEnv=new.env()
  read.gatingML(gateFile,flowEnv)
  fcs <- read.FCS(fcsFile,transformation=FALSE)
  
test.SpSc_G1<- function() {
	gateId<-"SpSc_G1"
	csvFile<-paste(csvFile,"/",gateId,".txt",sep="")
	expectedResult<-read.csv(csvFile,header=TRUE)
	flowUtils:::performGateTest(gateId,fcs,expectedResult,flowEnv)
}

test.SpSc_G2<- function() {
	gateId<-"SpSc_G2"
	csvFile<-paste(csvFile,"/",gateId,".txt",sep="")
	expectedResult<-read.csv(csvFile,header=TRUE)
	flowUtils:::performGateTest(gateId,fcs,expectedResult,flowEnv)
}

test.SpSc_G3<- function() {
	gateId<-"SpSc_G3"
	csvFile<-paste(csvFile,"/",gateId,".txt",sep="")
	expectedResult<-read.csv(csvFile,header=TRUE)
	flowUtils:::performGateTest(gateId,fcs,expectedResult,flowEnv)
}

test.SpSc_G4<- function() {
	gateId<-"SpSc_G4"
	csvFile<-paste(csvFile,"/",gateId,".txt",sep="")
	expectedResult<-read.csv(csvFile,header=TRUE)
	flowUtils:::performGateTest(gateId,fcs,expectedResult,flowEnv)
}

test.SpSc_G5<- function() {
	gateId<-"SpSc_G5"
	csvFile<-paste(csvFile,"/",gateId,".txt",sep="")
	expectedResult<-read.csv(csvFile,header=TRUE)
	flowUtils:::performGateTest(gateId,fcs,expectedResult,flowEnv)
}

test.SpSc_G6<- function() {
	gateId<-"SpSc_G6"
	csvFile<-paste(csvFile,"/",gateId,".txt",sep="")
	expectedResult<-read.csv(csvFile,header=TRUE)
	flowUtils:::performGateTest(gateId,fcs,expectedResult,flowEnv)
}

test.SpSc_G7<- function() {
	gateId<-"SpSc_G7"
	csvFile<-paste(csvFile,"/",gateId,".txt",sep="")
	expectedResult<-read.csv(csvFile,header=TRUE)
	flowUtils:::performGateTest(gateId,fcs,expectedResult,flowEnv)
}

test.SpSc_G8<- function() {
	gateId<-"SpSc_G8"
	csvFile<-paste(csvFile,"/",gateId,".txt",sep="")
	expectedResult<-read.csv(csvFile,header=TRUE)
	flowUtils:::performGateTest(gateId,fcs,expectedResult,flowEnv)
}

test.SpSc_G9<- function() {
	gateId<-"SpSc_G9"
	csvFile<-paste(csvFile,"/",gateId,".txt",sep="")
	expectedResult<-read.csv(csvFile,header=TRUE)
	flowUtils:::performGateTest(gateId,fcs,expectedResult,flowEnv)
}
