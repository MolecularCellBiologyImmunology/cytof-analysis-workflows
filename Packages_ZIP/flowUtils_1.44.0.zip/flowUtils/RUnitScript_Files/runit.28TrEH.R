  fcsFile<-system.file("extdata/List-modeDataFiles","int-10_events_6_parameters.fcs",package="gatingMLData")
  gateFile <- system.file("extdata/Gating-MLFiles","28TrEH.xml",package="gatingMLData")
  csvFile<-paste(system.file("extdata/ExpectedResults/28TrEH",package="gatingMLData"))
  flowEnv=new.env()
  read.gatingML(gateFile,flowEnv)
  fcs <- read.FCS(fcsFile,transformation=FALSE)


test.TrEH_G1<- function() {
	gateId<-"TrEH_G1"
	csvFile<-paste(csvFile,"/",gateId,".txt",sep="")
	expectedResult<-read.csv(csvFile,header=TRUE)
	flowUtils:::performGateTest(gateId,fcs,expectedResult,flowEnv)
}

test.TrEH_G2<- function() {
	gateId<-"TrEH_G2"
	csvFile<-paste(csvFile,"/",gateId,".txt",sep="")
	expectedResult<-read.csv(csvFile,header=TRUE)
	flowUtils:::performGateTest(gateId,fcs,expectedResult,flowEnv)
}

test.TrEH_G3<- function() {
	gateId<-"TrEH_G3"
	csvFile<-paste(csvFile,"/",gateId,".txt",sep="")
	expectedResult<-read.csv(csvFile,header=TRUE)
	flowUtils:::performGateTest(gateId,fcs,expectedResult,flowEnv)
}

test.TrEH_G4<- function() {
	gateId<-"TrEH_G4"
	csvFile<-paste(csvFile,"/",gateId,".txt",sep="")
	expectedResult<-read.csv(csvFile,header=TRUE)
	flowUtils:::performGateTest(gateId,fcs,expectedResult,flowEnv)
}

test.TrEH_G5<- function() {
	gateId<-"TrEH_G5"
	csvFile<-paste(csvFile,"/",gateId,".txt",sep="")
	expectedResult<-read.csv(csvFile,header=TRUE)
	flowUtils:::performGateTest(gateId,fcs,expectedResult,flowEnv)
}

test.TrEH_G6<- function() {
	gateId<-"TrEH_G6"
	csvFile<-paste(csvFile,"/",gateId,".txt",sep="")
	expectedResult<-read.csv(csvFile,header=TRUE)
	flowUtils:::performGateTest(gateId,fcs,expectedResult,flowEnv)
}

test.TrEH_G7<- function() {
	gateId<-"TrEH_G7"
	csvFile<-paste(csvFile,"/",gateId,".txt",sep="")
	expectedResult<-read.csv(csvFile,header=TRUE)
	flowUtils:::performGateTest(gateId,fcs,expectedResult,flowEnv)
}

test.TrEH_G8<- function() {
	gateId<-"TrEH_G8"
	csvFile<-paste(csvFile,"/",gateId,".txt",sep="")
	expectedResult<-read.csv(csvFile,header=TRUE)
	flowUtils:::performGateTest(gateId,fcs,expectedResult,flowEnv)
}

test.TrEH_G9<- function() {
	gateId<-"TrEH_G9"
	csvFile<-paste(csvFile,"/",gateId,".txt",sep="")
	expectedResult<-read.csv(csvFile,header=TRUE)
	flowUtils:::performGateTest(gateId,fcs,expectedResult,flowEnv)
}
