  fcsFile<-system.file("extdata/List-modeDataFiles","fcs2_int16_50000ev_8par_random.fcs",package="gatingMLData")
  gateFile <- system.file("extdata/Gating-MLFiles","17ParentIdTest.xml",package="gatingMLData")
  csvFile<-paste(system.file("extdata/ExpectedResults/17ParentIdTest",package="gatingMLData"))
  flowEnv=new.env()
  read.gatingML(gateFile,flowEnv)
  fcs <- read.FCS(fcsFile,transformation=TRUE)
 
test.prt_01<- function() {
  gateId<-"prt_01"
      csvFile<-paste(csvFile,"/",gateId,".txt",sep="")
      expectedResult<-read.csv(csvFile,header=TRUE)
      flowUtils:::performGateTest(gateId,fcs,expectedResult,flowEnv)
}

test.prt_02<- function() {
  gateId<-"prt_02"
      csvFile<-paste(csvFile,"/",gateId,".txt",sep="")
      expectedResult<-read.csv(csvFile,header=TRUE)
      flowUtils:::performGateTest(gateId,fcs,expectedResult,flowEnv)
}

test.prt_03<- function() {
  gateId<-"prt_03"
      csvFile<-paste(csvFile,"/",gateId,".txt",sep="")
      expectedResult<-read.csv(csvFile,header=TRUE)
      flowUtils:::performGateTest(gateId,fcs,expectedResult,flowEnv)
}

test.prt_04<- function() {
  gateId<-"prt_04"
      csvFile<-paste(csvFile,"/",gateId,".txt",sep="")
      expectedResult<-read.csv(csvFile,header=TRUE)
      flowUtils:::performGateTest(gateId,fcs,expectedResult,flowEnv)
}

test.prt_05<- function() {
  gateId<-"prt_05"
      csvFile<-paste(csvFile,"/",gateId,".txt",sep="")
      expectedResult<-read.csv(csvFile,header=TRUE)
      flowUtils:::performGateTest(gateId,fcs,expectedResult,flowEnv)
}

test.prt_08<- function() {
  gateId<-"prt_08"
      csvFile<-paste(csvFile,"/",gateId,".txt",sep="")
      expectedResult<-read.csv(csvFile,header=TRUE)
      flowUtils:::performGateTest(gateId,fcs,expectedResult,flowEnv)
}

test.prt_09<- function() {
  gateId<-"prt_09"
      csvFile<-paste(csvFile,"/",gateId,".txt",sep="")
      expectedResult<-read.csv(csvFile,header=TRUE)
      flowUtils:::performGateTest(gateId,fcs,expectedResult,flowEnv)
}

test.prt_10<- function() {
  gateId<-"prt_10"
      csvFile<-paste(csvFile,"/",gateId,".txt",sep="")
      expectedResult<-read.csv(csvFile,header=TRUE)
      flowUtils:::performGateTest(gateId,fcs,expectedResult,flowEnv)
}

test.prt_11<- function() {
  gateId<-"prt_11"
      csvFile<-paste(csvFile,"/",gateId,".txt",sep="")
      expectedResult<-read.csv(csvFile,header=TRUE)
      flowUtils:::performGateTest(gateId,fcs,expectedResult,flowEnv)
}

test.prt_12<- function() {
  gateId<-"prt_12"
      csvFile<-paste(csvFile,"/",gateId,".txt",sep="")
      expectedResult<-read.csv(csvFile,header=TRUE)
      flowUtils:::performGateTest(gateId,fcs,expectedResult,flowEnv)
}

test.prt_13<- function() {
  gateId<-"prt_13"
      csvFile<-paste(csvFile,"/",gateId,".txt",sep="")
      expectedResult<-read.csv(csvFile,header=TRUE)
      flowUtils:::performGateTest(gateId,fcs,expectedResult,flowEnv)
}

test.prt_14<- function() {
  gateId<-"prt_14"
      csvFile<-paste(csvFile,"/",gateId,".txt",sep="")
      expectedResult<-read.csv(csvFile,header=TRUE)
      flowUtils:::performGateTest(gateId,fcs,expectedResult,flowEnv)
}

test.prt_15<- function() {
  gateId<-"prt_15"
      csvFile<-paste(csvFile,"/",gateId,".txt",sep="")
      expectedResult<-read.csv(csvFile,header=TRUE)
      flowUtils:::performGateTest(gateId,fcs,expectedResult,flowEnv)
}

test.prt_16<- function() {
  gateId<-"prt_16"
      csvFile<-paste(csvFile,"/",gateId,".txt",sep="")
      expectedResult<-read.csv(csvFile,header=TRUE)
      flowUtils:::performGateTest(gateId,fcs,expectedResult,flowEnv)
}

test.prt_17<- function() {
  gateId<-"prt_17"
      csvFile<-paste(csvFile,"/",gateId,".txt",sep="")
      expectedResult<-read.csv(csvFile,header=TRUE)
      flowUtils:::performGateTest(gateId,fcs,expectedResult,flowEnv)
}

test.prt_18<- function() {
  gateId<-"prt_18"
      csvFile<-paste(csvFile,"/",gateId,".txt",sep="")
      expectedResult<-read.csv(csvFile,header=TRUE)
      flowUtils:::performGateTest(gateId,fcs,expectedResult,flowEnv)
}

test.prt_19<- function() {
  gateId<-"prt_19"
      csvFile<-paste(csvFile,"/",gateId,".txt",sep="")
      expectedResult<-read.csv(csvFile,header=TRUE)
      flowUtils:::performGateTest(gateId,fcs,expectedResult,flowEnv)
}

test.prt_20<- function() {
  gateId<-"prt_20"
      csvFile<-paste(csvFile,"/",gateId,".txt",sep="")
      expectedResult<-read.csv(csvFile,header=TRUE)
      flowUtils:::performGateTest(gateId,fcs,expectedResult,flowEnv)
}

test.prt_23<- function() {
  gateId<-"prt_23"
      csvFile<-paste(csvFile,"/",gateId,".txt",sep="")
      expectedResult<-read.csv(csvFile,header=TRUE)
      flowUtils:::performGateTest(gateId,fcs,expectedResult,flowEnv)
}

test.prt_24<- function() {
  gateId<-"prt_24"
      csvFile<-paste(csvFile,"/",gateId,".txt",sep="")
      expectedResult<-read.csv(csvFile,header=TRUE)
      flowUtils:::performGateTest(gateId,fcs,expectedResult,flowEnv)
}

test.prt_25<- function() {
  gateId<-"prt_25"
      csvFile<-paste(csvFile,"/",gateId,".txt",sep="")
      expectedResult<-read.csv(csvFile,header=TRUE)
      flowUtils:::performGateTest(gateId,fcs,expectedResult,flowEnv)
}

test.prt_p01<- function() {
  gateId<-"prt_p01"
      csvFile<-paste(csvFile,"/",gateId,".txt",sep="")
      expectedResult<-read.csv(csvFile,header=TRUE)
      flowUtils:::performGateTest(gateId,fcs,expectedResult,flowEnv)
}

test.prt_p02<- function() {
  gateId<-"prt_p02"
      csvFile<-paste(csvFile,"/",gateId,".txt",sep="")
      expectedResult<-read.csv(csvFile,header=TRUE)
      flowUtils:::performGateTest(gateId,fcs,expectedResult,flowEnv)
}

test.prt_p03<- function() {
  gateId<-"prt_p03"
      csvFile<-paste(csvFile,"/",gateId,".txt",sep="")
      expectedResult<-read.csv(csvFile,header=TRUE)
      flowUtils:::performGateTest(gateId,fcs,expectedResult,flowEnv)
}

test.prt_p04<- function() {
  gateId<-"prt_p04"
      csvFile<-paste(csvFile,"/",gateId,".txt",sep="")
      expectedResult<-read.csv(csvFile,header=TRUE)
      flowUtils:::performGateTest(gateId,fcs,expectedResult,flowEnv)
}

test.prt_p05<- function() {
  gateId<-"prt_p05"
      csvFile<-paste(csvFile,"/",gateId,".txt",sep="")
      expectedResult<-read.csv(csvFile,header=TRUE)
      flowUtils:::performGateTest(gateId,fcs,expectedResult,flowEnv)
}

test.prt_p06<- function() {
  gateId<-"prt_p06"
      csvFile<-paste(csvFile,"/",gateId,".txt",sep="")
      expectedResult<-read.csv(csvFile,header=TRUE)
      flowUtils:::performGateTest(gateId,fcs,expectedResult,flowEnv)
}

test.prt_p07<- function() {
  gateId<-"prt_p07"
      csvFile<-paste(csvFile,"/",gateId,".txt",sep="")
      expectedResult<-read.csv(csvFile,header=TRUE)
      flowUtils:::performGateTest(gateId,fcs,expectedResult,flowEnv)
}

test.prt_p08<- function() {
  gateId<-"prt_p08"
      csvFile<-paste(csvFile,"/",gateId,".txt",sep="")
      expectedResult<-read.csv(csvFile,header=TRUE)
      flowUtils:::performGateTest(gateId,fcs,expectedResult,flowEnv)
}

test.prt_p09<- function() {
  gateId<-"prt_p09"
      csvFile<-paste(csvFile,"/",gateId,".txt",sep="")
      expectedResult<-read.csv(csvFile,header=TRUE)
      flowUtils:::performGateTest(gateId,fcs,expectedResult,flowEnv)
}
